__version__ = "0.1.0"
__author__ = 'Motion Design Studio'
__credits__ = 'Motion Design Studio'